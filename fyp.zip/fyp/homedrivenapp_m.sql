-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2019 at 09:35 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `homedrivenapp_m`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(255) NOT NULL,
  `product_id` int(255) NOT NULL,
  `price` int(255) NOT NULL,
  `productname` varchar(255) NOT NULL,
  `user_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `product_id`, `price`, `productname`, `user_id`) VALUES
(1, 1, 22, 'OK', 2),
(3, 0, 222, 'name', 0),
(4, 0, 222, 'name', 0),
(5, 0, 222, 'name', 0),
(6, 0, 222, 'name', 0),
(7, 0, 222, 'name', 0);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(255) NOT NULL,
  `product_id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `service_id` int(255) NOT NULL,
  `views` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `description`, `price`, `image`, `user_id`, `service_id`, `views`) VALUES
(2, 'name', 'desc', '222', 'android-icon-48x48.png', 2, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` int(255) NOT NULL,
  `added_by` int(255) NOT NULL,
  `name` text NOT NULL,
  `total_post` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `added_by`, `name`, `total_post`) VALUES
(1, 1, 'Cooking', 126),
(2, 1, 'Flower Design', 1),
(3, 1, 'Handmade Jewellery', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `service` int(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(255) NOT NULL,
  `phone2` varchar(255) NOT NULL,
  `views` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `type`, `status`, `service`, `firstname`, `lastname`, `description`, `email`, `password`, `address`, `phone`, `phone2`, `views`) VALUES
(1, 'admin', '', 0, 'Kinza', 'Naeem', 'kinzanaeem321@gmail.com', 'kinzanaeem321@gmail.com', 'kinza', '', '', '', 0),
(2, 'provider', 'Approved', 0, 'Bisma Name', 'Munawar Last', 'Flowers are Available Edi', 'bisma@gmail.com', 'OK', 'Flowers are Available edi', '0314-9878361', '0314-9878361', 0),
(3, 'provider', 'pending', 1, 'first', 'last', 'desc', 'email', 'pass', 'address', 'phone', 'phon2', 0),
(4, 'provider', 'pending', 1, 'first', 'last', 'desc', 'email', 'pass', 'address', 'phone', 'phon2', 0),
(5, 'provider', 'pending', 1, 'first', 'last', 'desc', 'email', 'pass', 'address', 'phone', 'phon2', 0),
(6, 'provider', 'pending', 1, 'first', 'last', 'desc', 'email', 'pass', 'address', 'phone', 'phon2', 0),
(7, 'provider', 'pending', 1, '-9878038', '-9878038', 'desc', 'email', 'pass', 'address', 'phone', 'phon2', 0),
(8, 'provider', 'pending', 1, '0323-9878361', '0323-9878361', 'desc', 'email', 'pass', 'address', 'phone', 'phon2', 0),
(9, 'provider', 'pending', 1, '0323-9878361', '0323-9878361', '0323-9878361', 'cont@gmail.com', '0323-9878361', '0323-9878361', '0300-0000000', '0323-9878361', 0),
(10, 'provider', 'pending', 1, '0323-9878361', '0323-9878361', '0323-9878361', 'cont@gmail.com', '0323-9878361', '0323-9878361', '0300-0000000', '0323-9878361', 0),
(11, 'provider', 'pending', 1, '0323-9878361', '0323-9878361', '0323-9878361', 'cont@gmail.com', '0323-9878361', '0323-9878361', '0300-0000000', '0323-9878361', 0),
(12, 'provider', 'pending', 1, '0323-9878361', '0323-9878361', '0323-9878361', 'cont@gmail.com', '0323-9878361', '0323-9878361', '0300-0000000', '0323-9878361', 0),
(13, 'provider', 'pending', 1, '0323-9878361', '0323-9878361', '0323-9878361', 'cont@gmail.com', '0323-9878361', '0323-9878361', '0300-0000000', '0323-9878361', 0),
(14, 'provider', 'pending', 1, '0323-9878361', '0323-9878361', '0323-9878361', 'cont@gmail.com', '0323-9878361', '0323-9878361', '0300-0000000', '0323-9878361', 0),
(15, 'user', 'pending', 0, 'Mujahid', 'Khan', '', 'cont@gmail.com', 'abc', 'Full address', '0314-8617631', '', 0),
(16, 'user', 'pending', 0, 'Mujahid', 'Khan', '', 'cont@gmail.com', 'abc', 'address', '0314-8617631', '', 0),
(17, 'user', 'pending', 0, 'Mujahid', 'Khan', '', 'cont@gmail.com', 'abc', 'address', '0314-8617631', '', 0),
(18, 'user', 'pending', 0, 'Mujahid', 'Khan', '', 'cont@gmail.com', 'abc', 'address', '0314-8617631', '', 0),
(19, 'user', 'pending', 0, 'Mujahid', 'Khan', '', 'cont@gmail.com', 'abc', 'address', '0314-8617631', '', 0),
(20, 'user', 'pending', 0, 'Mujahid', 'Khan', '', 'cont@gmail.com', 'abc', 'address', '0314-8617631', '', 0),
(21, 'user', 'pending', 0, 'Mujahid', 'Khan', '', 'cont@gmail.com', 'abc', 'address', '0314-8617631', '', 0),
(22, 'user', 'pending', 0, 'Mujahid', 'Khan', '', 'cont@gmail.com', 'abc', 'address', '0314-8617631', '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
