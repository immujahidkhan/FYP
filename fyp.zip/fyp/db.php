<?php
$con = new mysqli('127.0.0.1','root','');
mysqli_select_db($con,'homedrivenapp_m');
if($con->connect_error)
{die("Connection failed: " . $con->connect_error);}
session_start();