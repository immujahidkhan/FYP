<?php
include '../db.php';
    $id=$_POST['id'];
    $sql="Delete from product where id=$id";
	mysqli_query($con,$sql);
header("refresh:0;url=showproducts.php");