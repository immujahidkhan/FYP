<?php 


    include('includes/header_files.php');
?>


<body>

	<div id="preloader">
        <div class="sk-spinner sk-spinner-wave" id="status">
            <div class="sk-rect1"></div>
            <div class="sk-rect2"></div>
            <div class="sk-rect3"></div>
            <div class="sk-rect4"></div>
            <div class="sk-rect5"></div>
        </div>
    </div><!-- End Preload -->

    <!-- Header ================================================== -->
    <?php 
           include_once('includes/header.php'); 
           ?>
    <!-- End Header =============================================== -->

<!-- SubHeader =============================================== -->
<?php 
           include_once('includes/cart3_sub_header.php'); 
           ?>
<!-- End SubHeader ============================================ -->

    

<!-- Content ================================================== -->
<div class="container margin_60_35">
	<div class="row">
		<div class="col-md-offset-3 col-md-6">
			<div class="box_style_2">
				<h2 class="inner">Order confirmed!</h2>
				<div id="confirm">
					<i class="icon_check_alt2"></i>
					<h3>Thank you!</h3>
					<p>
						
					</p>
				</div>
				<h4>Summary</h4>
				<table class="table table-striped nomargin">
				<tbody>
				<tr>
					<td>
						<strong>1x</strong> Biryani
					</td>
					<td>
						<strong class="pull-right">Rs 250</strong>
					</td>
				</tr>
				<tr>
					<td>
						<strong>2x</strong> Pizza
					</td>
					<td>
						<strong class="pull-right">Rs.1640</strong>
					</td>
				</tr>
				<tr>
					<td>
						<strong>1x</strong> Chicken Karahi
					</td>
					<td>
						<strong class="pull-right">Rs.300</strong>
					</td>
				</tr>
				<tr>
					<td>
						<strong>2x</strong> Ear Rings 
					</td>
					<td>
						<strong class="pull-right">Rs.950</strong>
					</td>
				</tr>
				<tr>
					<td>
						<strong>2x</strong> Necklace 
					</td>
					<td>
						<strong class="pull-right">Rs. 520</strong>
					</td>
				</tr>
				<tr>
					<td>
						 Delivery schedule <a href="#" class="tooltip-1" data-placement="top" title="" data-original-title="Please consider 30 minutes of margin for the delivery!"></a>
					</td>
					<td>
						<strong class="pull-right">Today 07.30 pm</strong>
					</td>
				</tr>
				<tr>
					<td class="total_confirm">
						 TOTAL
					</td>
					<td class="total_confirm">
						<span class="pull-right">Rs3760</span>
					</td>
				</tr>
				</tbody>
				</table>
			</div>
		</div>
	</div><!-- End row -->
</div><!-- End container -->
<!-- End Content =============================================== -->

<!-- Footer ================================================== -->
	<?php 
       include_once('includes/footer.php'); 
    ?> 
<!-- End Footer =============================================== -->

<div class="layer"></div><!-- Mobile menu overlay mask -->

<!-- Login modal -->  
<?php 
       include_once('includes/loginfooter.php');
        ?>    
<!-- End modal -->   
    
<!-- Register modal -->
<?php 
       include_once('includes/regfooter.php');
        ?>    
<!-- End Register modal -->
    
     <!-- Search Menu -->
	<div class="search-overlay-menu">
		<span class="search-overlay-close"><i class="icon_close"></i></span>
		<form role="search" id="searchform" method="get">
			<input value="" name="q" type="search" placeholder="Search..." />
			<button type="submit"><i class="icon-search-6"></i>
			</button>
		</form>
	</div>
	<!-- End Search Menu -->
    
<!-- COMMON SCRIPTS -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/common_scripts_min.js"></script>
<script src="js/functions.js"></script>
<script src="assets/validate.js"></script>

</body>
</html>