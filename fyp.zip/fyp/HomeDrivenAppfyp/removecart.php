<?php
if(isset($_GET['id'])){
                $cart_id = $_GET['id'];
            }
    include '../db1.php';    
$sql="delete from cart where cart_id=$cart_id";
mysqli_query($con,$sql);
header("refresh:0; url=index.php");