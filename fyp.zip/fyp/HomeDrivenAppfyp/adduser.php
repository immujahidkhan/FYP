<?php
include '../db.php';

    $fname=$_POST['firstname_order'];
    $lname=$_POST['lastname_order'];
	$phone=$_POST['tel_order'];
    $mail=$_POST['email_order'];
    $address=$_POST['address_order'];
    $type="user";
    $status="pending";
    $sql="INSERT INTO user(status,firstname,lastname,email,password,type,address,phone)
    VALUES('$status','$fname','$lname','$mail','abc','$type','$address','$phone')";
    mysqli_query($con,$sql);
    $_SESSION['user_id']=mysqli_insert_id($con);
    header("refresh:0; url=cart_2.php");
