<?php 


	include('includes/header_files.php');
?>
<body>

    <div id="preloader">
        <div class="sk-spinner sk-spinner-wave" id="status">
            <div class="sk-rect1"></div>
            <div class="sk-rect2"></div>
            <div class="sk-rect3"></div>
            <div class="sk-rect4"></div>
            <div class="sk-rect5"></div>
        </div>
    </div><!-- End Preload -->
    
    <!-- Header ================================================== -->
    	<?php 
           include_once('includes/header.php'); 
           ?>
	<!-- End Header =============================================== -->
    
    <!-- SubHeader =============================================== -->
        <?php 
           include_once('includes/video_header.php');
            ?> 
    <!-- End Header video -->

    <!-- End SubHeader ============================================ -->
    
   <!-- Content ================================================== -->
   <?php   
        include_once('includes/howwork.php'); 
        ?> 
         <!-- End row -->
        
    <!-- End container -->
    <div class="white_bg">
    <div class="container margin_60">
        
        <div class="main_title">
            <h2 class="nomargin_top">Choose from Most Popular</h2>
            <p>
                Select the Person From Which You Want Services
            </p>
        </div>
        
        <?php
              include '../db1.php';
              $sql="select * from user where status='Approved'";
              $result=mysqli_query($con,$sql);
              $count=mysqli_num_rows($result);
            
            while($count>0)
            {
                $row=mysqli_fetch_assoc($result);
                $count--;
                $product_id=$row['id'];
            ?>
        <div class="row">
            <div class="col-md-6">
                <a  href="detail_page.php?id=<?php echo $product_id; ?>" class="strip_list">
                    <div class="desc">
                        <div class="thumb_strip">
                            <img src="img/p1.png" alt="">
                        </div>
                        <h3><?php echo $row['firstname'] ." ".$row['lastname']; ?></h3>
                        <div class="type">
                            <h5>
                            <?php 
                            $sql2="select * from product where user_id=$row[id]";
                            $result2=mysqli_query($con,$sql2);
                            $row2=mysqli_fetch_assoc($result2);
                            echo $row2['name'];
                            ?>
                            </h5>    
                        </div>
                        <div class="location">
                            <?php echo $row['address'];?><br><br><span class="opening">Opens at 10:00 am</span>
                        </div>
                    </div>
                    <!-- End desc-->
                </a><!-- End strip_list-->
               <!-- End strip_list-->
            </div><!-- End col-md-6-->
            <?php
                        if($count>0)
                        {
                          $row=mysqli_fetch_assoc($result);
                            $count--;
                            $product_id=$row['id'];
                        ?>
            <div class="col-md-6">
                <a href="detail_page.php?id=<?php echo $product_id; ?>" class="strip_list">
                    <div class="desc">
                        <div class="thumb_strip">
                            <img src="img/p5.jpg" alt="">
                        </div>
                        
                        <h3><?php echo $row['name']." ".$row['lastname']; ?></h3>
                        <div class="type">
                            <h5><?php 
                            $sql2="select * from service where id=$row[service]";
                            $result2=mysqli_query($con,$sql2);
                            $row2=mysqli_fetch_assoc($result2);
                            echo $row2['name'];
                            ?>
                            </h5>
                        </div>
                        <div class="location">
                            <?php echo $row['address'];?><br><br><span class="opening">Opens at 10:00 am</span>
                        </div>
                    </div>
                    <!-- End desc-->
                </a><!-- End strip_list-->
               <!-- End strip_list-->
            </div><!-- End col-md-6-->
        </div><!-- End row -->
        <?php
        }
          }
        ?>
                    
        </div><!-- End container -->
        </div> <!-- End white_bg -->
    </div>
                  
    <!-- End Content ===============================================-->    
<div class="container margin_60">
      <div class="main_title margin_mobile">
            <h2 class="nomargin_top">Work with Us</h2>
            <p>
                Looking For a Work At home? 
            </p>
        </div> 
      	<div class="row" style="margin-left: 240px;">
            
            <div class="col-md-4 col-md-offset-2">
            	<a class="box_work" href="signup.php">
                <img src="img/picture.jpg" width="848" height="480" alt="" class="img-responsive">
                <h3>Submit your Service here<span>Start to earn customers</span></h3>
                <p></p>
                <div class="btn_1">Submit Here</div>
                </a>
            </div>

           
      </div><!-- End row -->
      </div><!-- End container -->
</div>
    
    <!-- Footer ================================================== -->
    <?php 
       include_once('includes/footer.php'); 
    ?> 
    
    <!-- End Footer =============================================== -->

<div class="layer"></div><!-- Mobile menu overlay mask -->

<!-- Login modal -->  
 
<!-- End modal -->   
    
<!-- Register modal -->
    
<!-- End Register modal -->
    
<!-- COMMON SCRIPTS -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/common_scripts_min.js"></script>
<script src="js/functions.js"></script>
<script src="assets/validate.js"></script>

<!-- SPECIFIC SCRIPTS -->
<script src="js/video_header.js"></script>
<script>
$(document).ready(function() {
	'use strict';
   	  HeaderVideo.init({
      container: $('.header-video'),
      header: $('.header-video--media'),
      videoTrigger: $("#video-trigger"),
      autoPlayVideo: true
    });    

});
</script>

</body>
</html>