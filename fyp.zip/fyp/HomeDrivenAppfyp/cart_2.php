<?php 


    include('includes/header_files.php');
?>


<body>

	<div id="preloader">
        <div class="sk-spinner sk-spinner-wave" id="status">
            <div class="sk-rect1"></div>
            <div class="sk-rect2"></div>
            <div class="sk-rect3"></div>
            <div class="sk-rect4"></div>
            <div class="sk-rect5"></div>
        </div>
    </div><!-- End Preload -->

    <!-- Header ================================================== -->
    <?php 
           include_once('includes/header.php'); 
           ?>
    <!-- End Header =============================================== -->

<!-- SubHeader =============================================== -->
<?php 
           include_once('includes/cart2_sub_header.php'); 
           ?>
<!-- End SubHeader ============================================ -->

    
    
<!-- Content ================================================== -->
<div class="container margin_60_35">
		<div class="row">
			<div class="col-md-3">
				<div class="box_style_2 hidden-xs info">
					<h4 class="nomargin_top">Delivery time <i class="icon_clock_alt pull-right"></i></h4>
					<p>
						8pm to 10am
					</p>
					<hr>
					<h4>Secure payment <i class="icon_creditcard pull-right"></i></h4>
					<p>
						Cash on Delivery
					</p>
				</div><!-- End box_style_2 -->
                
				<div class="box_style_2 hidden-xs" id="help">
					<i class="icon_lifesaver"></i>
					<h4>Need <span>Help?</span></h4>
					<a href="tel://004542344599" class="phone">041889933</a>
					<small>Monday to Friday 9.00am - 7.30pm</small>
				</div>
			</div><!-- End col-md-3 -->
            
			<div class="col-md-6">
				<div class="box_style_2">
					<h2 class="inner">Payment methods</h2>
					
					<div class="row">
						<div class="col-md-6">
					
							<img src="img/cash.jpg" width="500" height="230">
						</div>
						<div class="col-md-6 col-sm-12">
						
						</div>
					</div>   <!--End row--> 

					<div class="payment_select nomargin">
						<label><input type="radio" value="" name="payment_method" class="icheck">Pay with cash</label>
						<i class="icon_wallet"></i>
					</div> 
				</div><!-- End box_style_1 -->
			</div><!-- End col-md-6 -->
				<?php 
       include_once('includes/sidecart.php');
        ?> 

            					<a class="btn_full" href="confirmorder.php">Confirm your order</a>
				</div><!-- End cart_box -->
                </div><!-- End theiaStickySidebar -->
			</div><!-- End col-md-3 -->
            
		</div><!-- End row -->
</div><!-- End container -->
<!-- End Content =============================================== -->

<!-- Footer ================================================== -->
	<?php 
       include_once('includes/footer.php'); 
    ?> 
<!-- End Footer =============================================== -->

<div class="layer"></div><!-- Mobile menu overlay mask -->

<!-- Login modal -->
<?php 
       include_once('includes/loginfooter.php');
        ?>     
<!-- End modal -->   
    
<!-- Register modal -->  
<?php 
       include_once('includes/regfooter.php');
        ?>   
<!-- End Register modal -->
    
     <!-- Search Menu -->
	<div class="search-overlay-menu">
		<span class="search-overlay-close"><i class="icon_close"></i></span>
		<form role="search" id="searchform" method="get">
			<input value="" name="q" type="search" placeholder="Search..." />
			<button type="submit"><i class="icon-search-6"></i>
			</button>
		</form>
	</div>
	<!-- End Search Menu -->
    
<!-- COMMON SCRIPTS -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/common_scripts_min.js"></script>
<script src="js/functions.js"></script>
<script src="assets/validate.js"></script>

<!-- SPECIFIC SCRIPTS -->
<script src="js/ResizeSensor.min.js"></script>
<script src="js/theia-sticky-sidebar.min.js"></script>
<script>
    jQuery('#sidebar').theiaStickySidebar({
      additionalMarginTop: 80
    });
</script>

</body>
</html>