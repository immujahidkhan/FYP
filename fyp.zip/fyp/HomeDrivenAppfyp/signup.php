<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Provider Login </title>
    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="login">
      
      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <form action="includes/insertsignup.php" method="post">
              <h1>Sign up Form</h1>
                <input type="text" class="form-control" placeholder="First Name" name="fname" required>
				<input type="text" class="form-control" placeholder="Last Name" name="lname" required>
				<input type="email" class="form-control" placeholder="E-Mail" name="email" required/>
                <input type="text" class="form-control" placeholder="Contact 0300-0000000" name="contact" pattern="[0-9]{4}-[0-9]{7}" required>
                <input type="text" class="form-control" placeholder="Other Contact 0300-0000000" name="othercontact" pattern="[0-9]{4}-[0-9]{7}">
				<input type="password" class="form-control" placeholder="Password" name="pass" required>
				<input type="password" class="form-control" placeholder="Re_Enter Password" name="Rpass" required><br>
				<input type="text" class="form-control" placeholder="Description" name="des" required>
				<input type="text" class="form-control" placeholder="Address" name="address" required>
                <Select class="form-control" name="service">
                    <?php
					include "../db.php";
					$sql = "SELECT * FROM service";
					$result = $con->query($sql);
					while($row=$result->fetch_assoc())
					{		
                    ?>
						<option value=<?php echo $row['id']; ?> ><?php echo $row['name']; ?></option>';	
					<?php
                    }
					?>
                </Select>
                
                <button class="btn btn-default submit">Sign Up</button>
              <div class="separator"></div>    
            </form>
          </section>
        </div>
      </div>
  </body>
</html>