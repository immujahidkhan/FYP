<?php 


    include('includes/header_files.php');
?>
<body>

	<div id="preloader">
        <div class="sk-spinner sk-spinner-wave" id="status">
            <div class="sk-rect1"></div>
            <div class="sk-rect2"></div>
            <div class="sk-rect3"></div>
            <div class="sk-rect4"></div>
            <div class="sk-rect5"></div>
        </div>
    </div><!-- End Preload -->

    <!-- Header ================================================== -->
    <?php 
           include_once('includes/header.php'); 
           ?>
    <!-- End Header =============================================== -->

    <!-- SubHeader =============================================== -->
    <section class="parallax-window" id="short" data-parallax="scroll" data-image-src="img/contact1.jpg" data-natural-width="1400" data-natural-height="350">
        <div id="subheader">
            <div id="sub_content">
             <h1>Contacts</h1>
             <p>The support team is here to help you!!!</p>
            </div><!-- End sub_content -->
        </div><!-- End subheader -->
    </section><!-- End section -->
    <!-- End SubHeader ============================================ -->

    

<!-- Content ================================================== -->
<div class="container margin_60_35">
	<div class="row" id="contacts">
    	<div class="col-md-6 col-sm-6">
        	<div class="box_style_2" style="width: 1140px;">
            	<h2 class="inner"><center> Customer service </center></h2>
                <p class="add_bottom_30">"We don't want to push our ideas on to customers, we simply want to make what they want."  <br> <strong>Instead of focusing on the competition,WE focus on the customer.</strong></p>
                <p><a href="tel://004542344599" class="phone"><i class="icon-phone-circled"></i>  041889933</a></p>
                <p class="nopadding"><a href="mailto:customercare@sarsabz.com"><i class="icon-mail-3"></i> customercare@sarsabz.com</a></p>
            </div>
    	</div>
      
    </div><!-- End row -->
</div><!-- End container -->
<!-- End Content =============================================== -->

<!-- Footer ================================================== -->
	<?php 
       include_once('includes/footer.php'); 
    ?> 
<!-- End Footer =============================================== -->

<div class="layer"></div><!-- Mobile menu overlay mask -->

<!-- Login modal -->  
<?php 
       include_once('includes/loginfooter.php');
        ?>  
<!-- End modal -->   
    
<!-- Register modal -->
<?php 
       include_once('includes/regfooter.php');
        ?>      
<!-- End Register modal -->
    
     <!-- Search Menu -->
	<div class="search-overlay-menu">
		<span class="search-overlay-close"><i class="icon_close"></i></span>
		<form role="search" id="searchform" method="get">
			<input value="" name="q" type="search" placeholder="Search..." />
			<button type="submit"><i class="icon-search-6"></i>
			</button>
		</form>
	</div>
	<!-- End Search Menu -->
    
<!-- COMMON SCRIPTS -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/common_scripts_min.js"></script>
<script src="js/functions.js"></script>
<script src="assets/validate.js"></script>

</body>
</html>