<?php
include("../db.php");
$id=$_POST['id'];
$name = $_POST['name'];
$lname = $_POST['lname'];
$des = $_POST['des'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$phone2 = $_POST['phone2'];
$pass = $_POST['pass'];
$sql = "UPDATE user SET
firstname='{$name}',
lastname='{$lname}',
description='{$des}',
address='{$address}',
phone='{$phone}',
phone2='{$phone2}',
password='{$pass}'
where id ='$id'";
if(mysqli_query($con,$sql))
	{	
        header("refresh:0;url=provider.php");
		exit;
	}

?>

