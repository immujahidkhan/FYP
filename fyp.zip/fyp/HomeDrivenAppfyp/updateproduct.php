<?php
include '../db.php';
$id=$_POST['id'];
$name = $_POST['name'];
$des = $_POST['des'];
$price = $_POST['price'];
$img = $_POST['img'];
$sql = "UPDATE product SET
name='{$name}',
description='{$des}',
image='{$img}',
price='{$price}'
where id ='$id'";
if(mysqli_query($con,$sql))
	{	
        header("refresh:0;url=showproducts.php");
		exit;
	}

?>

