<?php
include '../db.php';
    $target="img/".basename($_FILES['img']['name']);
    $image=$_FILES['img']['name'];
    $name=$_POST['name'];
	$price=$_POST['price'];
    $desc=$_POST['des'];
    $service=$_SESSION['service'];
    $provider=$_SESSION['id'];
    $sql="INSERT INTO product(name,description,price,user_id,image,service_id,views)
    VALUES('$name','$desc','$price','$provider','$image','$service',0)";
    move_uploaded_file($_FILES['img']['tmp_name'],$target);
    mysqli_query($con,$sql);
    header("refresh:0; url=addproducts.php");