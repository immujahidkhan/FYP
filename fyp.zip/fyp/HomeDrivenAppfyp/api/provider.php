<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// include database and object files
require_once("class.user.php");
$auth_user = new USER();

$perpage = 10;
//$perpage = $_GET["perpage"];

if(isset($_GET["page"])){
$page = intval($_GET["page"]);
}
else {
$page = 1;
}
$calc = $perpage * $page;
$start = $calc - $perpage;
//rand()
$cats = $auth_user->runFun("SELECT * FROM `provider` order by id asc limit $start,$perpage");
$num = $cats->rowCount();
    // products array
    $products_arr=array();
    $products_arr["Providers"]=array();
	 while ($row = $cats->fetch(PDO::FETCH_ASSOC)){
      	 
		 $catsData = $auth_user->runFun("SELECT * FROM `service` where service_id = '$row[service]'");
		 $catsRow = $catsData->fetch(PDO::FETCH_ASSOC);
        
		$product_item=array(
            "id" => $row['id'],
            "name" => ucwords($row['name']),
            "service" => ucwords($row['service']),
            "serviceTitle" => ucwords($catsRow['name']),
            "description" => ucwords($row['description']),
            "address" => ucwords($row['address']),
            "phone" => ucwords($row['phone']),
            "phone2" => ucwords($row['phone2']),
            "status" => ucwords($row['status']),
            "email" => ucwords($row['email']),
            "password" => ucwords($row['password'])
        );
 
        array_push($products_arr["Providers"], $product_item);
    }
 
    echo json_encode($products_arr);
	
?>