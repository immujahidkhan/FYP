<?php
include '../db.php';
if(!isset($_SESSION['email']))
{
	header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Provider Panel</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <?php include 'includes/common.php'; ?>
            <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Providers</h3>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Projects</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <!-- start project list -->
                    <table class="table table-striped projects">
                      <thead>
                        <tr>
                          <th style="width: 10%">Sr.</th>
                          <th style="width: 10%">Name</th>
                          <th style="width: 10%">Description</th>
                          <th style="width: 10%">Price</th>
                          <th style="width: 10%">Delete</th>
                          <th style="width: 10%">Edit</th>
                        </tr>
                      </thead>
                    <?php
                      $sql = "SELECT * FROM provider";
                      $count=1;
                      $sql = "SELECT * FROM product where user_id=$_SESSION[id]";
                      $result = $con->query($sql);
                      if ($result->num_rows > 0) 
                      {
                          while($row = $result->fetch_assoc()) 
                          {
                    ?>
                      <tbody>
                        <tr>
                          <td><?php echo $count; ?></td>
                          <td><?php echo $row['name']; ?></td>
                          <td><?php echo $row['description']; ?></td>
                          <td><?php echo $row['price']; ?></td>
                          <td>
                        <form action="deleteproducts.php" method="post">
                            <input style="display:none" type="text" value="<?php echo $row['id']; ?>" name="id" class="btn btn-danger btn-xs"/>
                            <input type="submit" value="Delete" class="btn btn-danger btn-xs"/>
                        </form>
                            </td>
                            <td>
                        <form action="updateproducts.php" method="post">
                            <input style="display:none" type="text" value="<?php echo $row['id']; ?>" name="id" class="btn btn-danger btn-xs"/>
                            <input type="submit" value="Edit" class="btn btn-info btn-xs"/>
                        </form>
                        </td>
                        </tr>
                      </tbody>
                        <?php
                              $count++;
                          }
                      }
                        else 
                        {
                            echo "<h1>No results</h1>";
                        }
                        ?>
                    </table>
                    <!-- end project list -->
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>