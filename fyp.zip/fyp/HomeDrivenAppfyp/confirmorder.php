<?php
include '../db.php';
    $fname=$_POST['firstname_order'];
    $lname=$_POST['lastname_order'];
	$phone=$_POST['tel_order'];
    $mail=$_POST['email_order'];
    $address=$_POST['address_order'];
    $type="user";
    $sql="select * from cart";
    $result=mysqli_query($con,$sql);
    $sql="select * from product";
    $result=mysqli_query($con,$sql);
    $sql="select * from cart";
    $result=mysqli_query($con,$sql);
    while($row=mysqli_fetch_assoc($result))
    {
        $sql="insert into order";
        $result=mysqli_query($con,$sql);
    
    }
    //header("refresh:0; url=cart_2.php");