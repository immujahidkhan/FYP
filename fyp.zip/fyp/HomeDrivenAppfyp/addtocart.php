<?php
if(isset($_GET['id'])){
                $product_id = $_GET['id'];
            }
    include '../db1.php';    
$sql="select * from product where id=$product_id";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($result);
$sql2="insert into cart(productname,price )
values('$row[name]','$row[price]')";
mysqli_query($con,$sql2);
    header("refresh:0; url=detail_page.php?id=$product_id");