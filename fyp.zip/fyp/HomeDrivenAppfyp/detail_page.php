<?php 
    session_start();
    include('includes/header_files.php');
?>

<body>

	<div id="preloader">
        <div class="sk-spinner sk-spinner-wave" id="status">
            <div class="sk-rect1"></div>
            <div class="sk-rect2"></div>
            <div class="sk-rect3"></div>
            <div class="sk-rect4"></div>
            <div class="sk-rect5"></div>
        </div>
    </div><!-- End Preload -->

    <!-- Header ================================================== -->
    <?php 
           include_once('includes/header.php'); 
           ?>
    <!-- End Header =============================================== -->

<!-- SubHeader =============================================== -->
<section class="parallax-window" data-parallax="scroll" data-image-src="img/picss.jpg" data-natural-width="1400" data-natural-height="470">
    <div id="subheader">
	<div id="sub_content">
        <?php
            if(isset($_GET['id'])){
                $product_id = $_GET['id'];
            }
            include '../db1.php';
            $sql="select * from user where id=$product_id";
            $result=mysqli_query($con,$sql);
            $row=mysqli_fetch_assoc($result);
            
        ?>
    	<div id="thumb"><img src="img/p1.png" alt=""></div>
                     <h1><?php echo $row['firstname']; ?></h1>
                    <div><i class="icon_pin"></i><?php echo $row['address']; ?></div>
    </div><!-- End sub_content -->
</div><!-- End subheader -->
</section><!-- End section -->
<!-- End SubHeader ============================================ -->


<!-- Content ================================================== -->


<div class="container margin_60_35">
		<div class="row">
        
			<div class="col-md-3">
            	<p><a href="index.php" class="btn_side">Back to search</a></p>
                
                
				<div class="box_style_2 hidden-xs" id="help">
					<i class="icon_lifesaver"></i>
					<h4>Need <span>Help?</span></h4>
					<a href="tel://004542344599" class="phone">041889933</a>
					<small>Monday to Friday 9.00am - 7.30pm</small>
				</div>
			</div><!-- End col-md-3 -->
            
			<div class="col-md-6">
				<div class="box_style_2" id="main_menu">
					<h2 class="inner"><?php echo $row['firstname']; ?></h2>
					<h3 class="nomargin_top" id="starters">
                    <?php
                    $sql2="select * from service where id=$row[service]";
                    $result2=mysqli_query($con,$sql2);
                    $row2=mysqli_fetch_assoc($result2);
                    echo $row2['name'];    
                    ?>
                    </h3>
					<p>
						<?php echo $row['description']; ?>

					</p>
					<table class="table table-striped cart-list">
					<thead>
					<tr>
						<th>Item</th>
						<th>Price</th>
						<th>Order</th>
					</tr>
					</thead>    
					<tbody>
                    <?php
                    $count=1;
                    $sql="select * from product where id=$product_id";
                    $result=mysqli_query($con,$sql);
                    if(mysqli_num_rows($result))
                    {
                    while($row=mysqli_fetch_assoc($result))
                    { 
                        $product_id=$row['id'];
                    ?>
					<tr>
						<td>
                        	<figure class="thumb_menu_list"><img src="img/<?php echo $row['image']; ?>" alt="thumb"></figure>
							<h5><?php echo $count.". ".$row['name']; ?></h5>
							<p>
								 <?php echo $row['description']; ?>
							</p>
						</td>
						<td>
							<strong><?php echo $row['price']; ?></strong>
						</td>
                        <td class="options">   
                        <div class="dropdown dropdown-options">
                            <a href="addtocart.php?id=<?php echo $product_id; ?>" class="dropdown-toggle" aria-expanded="true"><i class="icon_plus_alt2"></i></a>
                        </div> 
                        </td>
                            
                        </tr>
                        <?php
                        $count++;
                        }
                        }
                        else
                        {
                            echo "This person has added no product yet";
                        }
                        ?>
					</tbody>
					</table>

					
                
				</div><!-- End box_style_1 -->
			</div> <!-- End col-md-6 -->
			        <?php 
       include_once('includes/sidecart.php');
        ?> 
        <a class="btn_full" href="cart.php">Order now</a>
                </div><!-- End cart_box -->
                </div><!-- End theiaStickySidebar -->
            </div><!-- End col-md-3 -->
            
		</div><!-- End row -->
</div><!-- End container -->
<!-- End Content =============================================== -->

<!-- Footer ================================================== -->
	<?php 
       include_once('includes/footer.php'); 
    ?> 
<!-- End Footer =============================================== -->

<div class="layer"></div><!-- Mobile menu overlay mask -->
    
<!-- Login modal --> 

<?php 
       include_once('includes/loginfooter.php');
        ?>    
<!-- End modal -->   
    
<!-- Register modal --> 
<?php 
       include_once('includes/regfooter.php');
        ?>      
<!-- End Register modal -->
    
    <!-- Search Menu -->
	<div class="search-overlay-menu">
		<span class="search-overlay-close"><i class="icon_close"></i></span>
		<form role="search" id="searchform" method="get">
			<input value="" name="q" type="search" placeholder="Search..." />
			<button type="submit"><i class="icon-search-6"></i>
			</button>
		</form>
	</div>
	<!-- End Search Menu -->
    
<!-- COMMON SCRIPTS -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/common_scripts_min.js"></script>
<script src="js/functions.js"></script>
<script src="assets/validate.js"></script>

<!-- SPECIFIC SCRIPTS -->
<script  src="js/cat_nav_mobile.js"></script>
<script>$('#cat_nav').mobileMenu();</script>
<script src="js/ResizeSensor.min.js"></script>
<script src="js/theia-sticky-sidebar.min.js"></script>
<script>
    jQuery('#sidebar').theiaStickySidebar({
      additionalMarginTop: 80
    });
</script>
<!-- SMOOTH SCROLL -->
<script>
	$('#cat_nav a[href^="#"]').click(function() {
		if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') 
			|| location.hostname == this.hostname) {
			var target = $(this.hash);
			target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
			   if (target.length) {
				 $('html,body').animate({
					 scrollTop: target.offset().top -75
				}, 800);
				return false;
			}
		}
	});
</script>
</body>
</html>