<header>
    <div class="container-fluid">
        <div class="row">
            <div class="col--md-4 col-sm-4 col-xs-4">
                 <a href="index.php" id="logo">
                <img src="img/logo3.png" width="120" height="40" alt="" data-retina="true" class="hidden-xs" style="margin-top: 0px;">
                <img src="img/logo3.png" width="59" height="23" alt="" data-retina="true" class="hidden-lg hidden-md hidden-sm">
                </a>
                

            </div>
           <?php include_once('header_navbar.php'); ?>
        </div><!-- End row -->
    </div><!-- End container -->
    </header>