<?php
	include'../../db.php';
	echo $email = $_POST["email"];
	echo $password = $_POST["pass"];
	$sql="SELECT * FROM user where email='$email' && type = 'provider' && password= '$password'";
        $result =mysqli_query($con,$sql);
	
        if(mysqli_num_rows($result)>0)
          {
			  $row=mysqli_fetch_assoc($result);
              $_SESSION['id'] = $row['id'];
              $_SESSION['email'] = $row['email'];
              $_SESSION['name'] =$row['firstname'];
              $_SESSION['service']=$row['service'];
            header("refresh:0; url=../provider.php");
			exit;
          }
         else
		{
			
			//header("refresh:0; url=../login.php");
			//exit;
		}
		
?>