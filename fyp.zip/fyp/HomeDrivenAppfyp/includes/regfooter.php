<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="myRegister" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content modal-popup">
				<a href="#" class="close-link"><i class="icon_close_alt2"></i></a>
				 <img src="img/logo3.png" width="140" height="60" alt="" data-retina="true" class="hidden-xs" style="margin-top: 50px; ">
				<form action="#" class="popup-form" id="myRegister">
                	<div class="login_icon"></div>
					<input type="text" class="form-control form-white" name="first_name" placeholder="Name" pattern="[a-zA-Z\s]+" >

					<input type="text" class="form-control form-white" name="last_name" placeholder="Last Name" pattern="[a-zA-Z\s]+" >
                    <input type="email" class="form-control form-white" name="email" placeholder="Email"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$">

                    <input type="text" class="form-control form-white" name="create_password"  placeholder="Password"  id="password1">

                    <input type="text" class="form-control form-white" name="confirm_password" placeholder="Confirm password"  id="password2">
                    <div id="pass-info" class="clearfix"></div>
					<div class="checkbox-holder text-left">
						<div class="checkbox">
							<input type="checkbox" value="accept_2" id="check_2" name="check_2" />
							<label for="check_2"><span>I Agree to the <strong>Terms &amp; Conditions</strong></span></label>
						</div>
					</div>
					<button type="submit" name="reg" class="btn btn-submit">Register</button>
				</form>
								<?php
	include ('config.php');

	if(isset($_GET['reg'])){
$first_name =mysqli_real_escape_string($conn,@$_GET['first_name']) ;	
$last_name =mysqli_real_escape_string($conn,@$_GET['last_name']) ;	
$email =mysqli_real_escape_string($conn,@$_GET['email']);	
$create_password =mysqli_real_escape_string($conn,@$_GET['create_password']);
$confirm_password =mysqli_real_escape_string($conn,@$_GET['confirm_password']);


		$qry = "INSERT INTO user_registeration ( first_name,last_name,email,create_password,confirm_password)
		values('$first_name','$last_name','$email','$create_password','$confirm_password')";

	$run_qry = mysqli_query($conn,$qry);
	
	if($run_qry){
		echo "Data has been Inserted";
	}
	else{
		echo "Error".mysqli_error($conn);
	}
	}	
 
 ?>
	
			</div>
		</div>
	</div>
	