<?php
include '../../db.php';
    $fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$email=$_POST['email'];
	$pass=$_POST['pass'];
	$contact=$_POST['contact'];    
	$Ocontact=$_POST['othercontact'];    
    $desc=$_POST['des'];
    $address=$_POST['address'];
    $service=$_POST['service'];
    $status="Not Approved";
    $sql="INSERT INTO `user`(`type`, `status`, `service`, `firstname`, `lastname`, `description`, `email`, `password`, `address`, `phone`, `phone2`,`views`) 
	VALUES ('provider','pending','$service','$fname','$lname','$desc','$email','$pass','$address','$contact','$Ocontact',0)";
    
	if(mysqli_query($con,$sql))
	{
		//echo $service;
	$updateQ = "UPDATE `service` SET `total_post`=total_post+1 where id = '$service'";
	mysqli_query($con,$updateQ);
	header("refresh:0; url=../login.php");
	}
	?>