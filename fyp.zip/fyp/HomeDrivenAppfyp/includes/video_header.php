<section class="header-video">
    <div id="hero_video">
        <div id="sub_content">
            <h1>We are Differently Available</h1>
            <p>
                <i> <q>Stop Dreaming Start Doing </q> </i>
            </p>
            <form method="post" action="list_page.html">
                <div id="custom-search-input">
                    <div class="input-group">
                        <input type="text" class=" search-query" placeholder="Search your services">
                        <span class="input-group-btn">
                        <input type="submit" class="btn_search" value="submit">
                        </span>
                    </div>
                </div>
            </form>
        </div><!-- End sub_content -->
    </div>
    <img src="img/video_fix.png" alt="" class="header-video--media" data-video-src="" data-teaser-source="video/videoo" data-provider="" data-video-width="1920" data-video-height="960">


    </section>