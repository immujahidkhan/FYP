<div class="col-md-3" id="sidebar">
            <div class="theiaStickySidebar">
				<div id="cart_box" >
					<h3>Your order <i class="icon_cart_alt pull-right"></i></h3>
					<table class="table table_summary">
					<tbody>
					<?php
                        include '../db1.php';
                        $sql="select * from cart";
                        $result=mysqli_query($con,$sql);
                        while($row=mysqli_fetch_assoc($result))
                        {
                            $cart_id=$row['id'];
                        ?>
                        <tr>
						<td>
							<a href="removecart.php?id=<?php echo $cart_id; ?>" class="remove_item"><i class="icon_minus_alt"></i></a>
                            <a><?Php echo " " .$row['productname'] ?></a>
						</td>
						<td>
							<strong class="pull-right">Rs.<?Php echo $row['price'] ?></strong>
						</td>
					</tr>
                        <?php
                        }
                        ?>
					</tbody>
					</table>
					<hr>
					<hr>
					<table class="table table_summary">
					<tbody>
					<tr>
						<td class="total">
                            <?php
                            $total=0;
                            $sql="select * from cart";
                            $result=mysqli_query($con,$sql);
                            while($row=mysqli_fetch_assoc($result))
                            {
                                $total=$total+$row['price'];
                            }
                            ?>
							 TOTAL <span class="pull-right"><?php echo "Rs: ".$total    ?></span>
						</td>
					</tr>
					</tbody>
					</table>
					<hr>