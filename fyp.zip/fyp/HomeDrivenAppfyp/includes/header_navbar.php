 <nav class="col--md-8 col-sm-8 col-xs-8">
               
            <a class="cmn-toggle-switch cmn-toggle-switch__htx open_close" href="javascript:void(0);"><span>Menu mobile</span></a>
            <div class="main-menu">
                <div id="header_menu">
                    <img src="img/logo.png" width="190" height="23" alt="" data-retina="true">
                </div>
                <a href="#" class="open_close" id="close_in"><i class="icon_close"></i></a>
                <ul>
                    <li class="submenu">
                    <a href="index.php">Home</a>
                    
                    </li>
                    <li class="submenu">
                    <a href="cart.php" class="show-submenu">Order<i class="icon-down-open-mini"></i></a>
                    </li>
                    <li><a href="about.php">About us</a></li>
                    <li><a href="login.php">Become a service provider</a></li>
                    <li class="submenu"><a href="contacts.php" class="show-submenu">Contact</a> </li>

                    </ul>
                    </li>   
                </ul>
            </div><!-- End main-menu -->
            </nav>