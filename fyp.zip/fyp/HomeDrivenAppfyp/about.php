<?php 


    include('includes/header_files.php');
?>

<body>

	<div id="preloader">
        <div class="sk-spinner sk-spinner-wave" id="status">
            <div class="sk-rect1"></div>
            <div class="sk-rect2"></div>
            <div class="sk-rect3"></div>
            <div class="sk-rect4"></div>
            <div class="sk-rect5"></div>
        </div>
    </div><!-- End Preload -->

    <!-- Header ================================================== -->
    <?php
         include_once('includes/header.php'); 
         ?>
    <!-- End Header =============================================== -->

<!-- SubHeader =============================================== -->
<section class="parallax-window" id="short" data-parallax="scroll" data-image-src="img/picss.jpg" data-natural-width="1400" data-natural-height="350">
    <div id="subheader">
    	<div id="sub_content">
    	 <h1>About us</h1>
         <p><q>Stop dreaming start doing</q></p>
         <p></p>
        </div><!-- End sub_content -->
	</div><!-- End subheader -->
</section><!-- End section -->
<!-- End SubHeader ============================================ -->

<!-- Content ================================================== -->
<div class="container margin_60_35">
	<div class="row">
		<div class="col-md-4">
			<h3 class="nomargin_top">Some words about us</h3>
			<p>
				 Our basic Purpose is to target those women who not able to work due to  social restrictions. Our APP is basically provide them way to earn for their selves.
			</p>
			<p>
				 It is a real world problem that our society hardly accepts those women
                  ( Aged , Divorced, Disabled) who step out from their homes for  respectful earning . We provide them a motivational platform to encourages them to earn for their selves without stepping out.

			</p>
			<h4>Mission</h4>
			<p>
				 Our Mission is to develop people, especially unemployed people, socially, economically, and emotionally. ... To succeed and excel to provide work at home  which will help unemployed work seekers to find and perform work at home.
			</p>
			
		</div>
		<div class="col-md-7 col-md-offset-1 text-right hidden-sm hidden-xs">
			<img src="img/picture1.png" style="height:100%;width:100%"alt="" class="img-responsive">
		</div>
	</div><!-- End row -->
	<hr class="more_margin">
    <div class="main_title">
            <h2 class="nomargin_top"> Quality feautures</h2>
           <!-- <p>
                Cum doctus civibus efficiantur in imperdiet deterruisset.
            </p>-->
        </div>
	<div class="row">
		<div class="col-md-6 wow fadeIn" data-wow-delay="0.1s">
			<div class="feature">
				<i class="icon_building"></i>
				<h3><span>+ 1000</span> Employees</h3>
				<p>
                     Congratulations for being a part of our team. Our whole team welcomes a new employee like you. We are looking forward for the organization success with you. Welcome aboard.
				</p>
			</div>
		</div>
		<div class="col-md-6 wow fadeIn" data-wow-delay="0.2s">
			<div class="feature">
				<i class="icon_documents_alt"></i>
				<h3><span>Different</span> services Menu</h3>
				<p>
					 We provide different services at one platform .you choose servicee according to your skill and serve the people.
				</p>
			</div>
		</div>
	</div><!-- End row -->
	<div class="row">
		<div class="col-md-6 wow fadeIn" data-wow-delay="0.3s">
			<div class="feature">
				<i class="icon_bag_alt"></i>
				<h3><span>Delivery</span> or Takeaway</h3>
				<p>
					 You call and order. They tell you at what time in which your order will be ready. You go and pick up your order at that time and take it home. 

				</p>
			</div>
		</div>
		<div class="col-md-6 wow fadeIn" data-wow-delay="0.4s">
			<div class="feature">
				<i class="icon_mobile"></i>
				<h3><span>Mobile</span> support</h3>
				<p>
					 The mobile web, also known as mobile internet, refers to browser-based Internet services accessed from handheld mobile devices, such as smartphones or feature phones, through a mobile or other wireless network.
				</p>
			</div>
		</div>
	</div><!-- End row -->
	<div class="row">
		<div class="col-md-6 wow fadeIn" data-wow-delay="0.5s">
			<div class="feature">
				<i class="icon_wallet"></i>
				<h3><span>Cash</span> payment</h3>
				<p>
					 Money  paid for goods or services at the time of purchase or delivery.

				</p>
			</div>
		</div>
		<div class="col-md-6 wow fadeIn" data-wow-delay="0.6s">
			<div class="feature">
				<i class="icon_creditcard"></i>
				<h3><span>Secure cash</span> payment</h3>
				<p>
                     Money  paid for goods or services at the time of purchase or delivery in the secure way.

				</p>
			</div>
		</div>
	</div><!-- End row -->
</div><!-- End container -->

<div class="container-fluid">
	<div class="row">
		<div class="col-md-6 nopadding features-intro">
			<div class="features-bg ">
				<div class="features-img">
				<img class="img-responsive" src="img/img.jpg"style="height:100%;width:100%">
				</div>
			</div>
		</div>
		<div class="col-md-6 nopadding">
			<div class="features-content">
				<p>
				<h4><q><b><i>We are differently availabale</q></b></i></h4>
				</p>
				<p>
					<q><i><b>It doesn’t matter who you are, where you come from. The ability to triumph begins with you. Always.</i></b></q>
				</p>
				<p>
					<q><i><b>In the middle of difficulty lies opportunity.</i></b></q>
				</p>
			</div>
		</div>
	</div>
</div><!-- End container-fluid  -->
<!-- End Content =============================================== -->

<!-- Footer ================================================== -->
	<?php
	    include_once('includes/footer.php'); 
	    ?> 
<!-- End Footer =============================================== -->

<div class="layer"></div><!-- Mobile menu overlay mask -->

<!-- Login modal -->  
<?php 
     include_once('includes/loginfooter.php'); 
     ?>   
<!-- End modal -->   
    
<!-- Register modal -->   
<?php 
     include_once('includes/regfooter.php');
      ?>
<!-- End Register modal -->
    
     <!-- Search Menu -->
	<div class="search-overlay-menu">
		<span class="search-overlay-close"><i class="icon_close"></i></span>
		<form role="search" id="searchform" method="get">
			<input value="" name="q" type="search" placeholder="Search..." />
			<button type="submit"><i class="icon-search-6"></i>
			</button>
		</form>
	</div>
	<!-- End Search Menu -->
    
<!-- COMMON SCRIPTS -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/common_scripts_min.js"></script>
<script src="js/functions.js"></script>
<script src="assets/validate.js"></script>

</body>
</html>