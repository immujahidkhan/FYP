<?php 


	include('includes/header_files.php');
?>

<body>

	<div id="preloader">
        <div class="sk-spinner sk-spinner-wave" id="status">
            <div class="sk-rect1"></div>
            <div class="sk-rect2"></div>
            <div class="sk-rect3"></div>
            <div class="sk-rect4"></div>
            <div class="sk-rect5"></div>
        </div>
    </div><!-- End Preload -->

    <!-- Header ================================================== -->
    <?php 
           include_once('includes/header.php'); 
           ?>
    <!-- End Header =============================================== -->

<!-- SubHeader =============================================== -->
<section class="parallax-window" id="short" data-parallax="scroll" data-image-src="img/picss.jpg" data-natural-width="1400" data-natural-height="350">
    <div id="subheader">
    	<div id="sub_content">
    	 <h1>Work with us</h1>
         <p> <i> <q>Stop Dreaming Start Doing </q> </i> </p>
         <p></p>
        </div><!-- End sub_content -->
	</div><!-- End subheader -->
</section><!-- End section -->
<!-- End SubHeader ============================================ -->


<div class="container margin_60">
	 <div class="main_title margin_mobile">
            <h2 class="nomargin_top">Please Submit The Form Below</h2>
            <p>
					
	            </p>
        </div>
	<div class="row">
    	<div class="col-md-8 col-md-offset-2">
        	<form method="Post">
						<div class="row">
							<div class="col-md-6 col-sm-6">
								<div class="form-group">
									<label>First Name</label>
									<input type="text" class="form-control" id="name_contact" name="s_first_name" placeholder="" minlength="3" maxlength="25" autofocus  required="required" 
									pattern="[a-zA-Z\s]+" title="Minimum Three Characters only letters for User name">
								</div>
							</div>
							<div class="col-md-6 col-sm-6">
								<div class="form-group">
									<label>Last Name</label>
									<input type="text" class="form-control" id="lastname_contact" name="s_last_name" placeholder="" minlength="3" maxlength="25" autofocus  required="required" pattern="[a-zA-Z\s]+" title="Minimum Three Characters only letters for User name">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6 col-sm-6">
								<div class="form-group">
									<label>Email:</label>
									<input type="email" id="email_contact" name="s_email" class="form-control " placeholder="ali@email.com" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$">
								</div>
							</div>
							<div class="col-md-6 col-sm-6">
								<div class="form-group">
									<label>Phone number Format: +92(345)1234-789
				<span class="eci_req_star">*</span>
			</label>
									<input type="text" id="phone_contact" name="s_phone_no" class="form-control" placeholder="" pattern="[\+]\d{2}[\(]\d{3}[\)]\d{4}[\-]\d{3}" >
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label>Service name</label>
                                   <input type="text" id="restaurant" name="s_service_name" class="form-control" placeholder="">
								</div>
							</div>
                            <div class="col-md-6">
								<div class="form-group">
									<label>Address</label>
                                   <input type="address" id="restaurant_web" name="s_address" class="form-control" placeholder="" pattern="[a-zA-Z0-9 ]{2,50}]" >
								</div>
							</div> 
						</div><!-- End row  -->
                        <div class="row">
							<div class="col-md-6">
								<div class="form-group">
                                	<label>City</label>
                                   <input type="text" id="restaurant_city" name="s_city" class="form-control" placeholder="Faisalabad">
								</div>
							</div>
                            <div class="col-md-6">
								<div class="form-group">
                               
                                	<label>Other Contact Format: +92(345)1234-789
				<span class="eci_req_star">*</span>
			</label>
                                   <input type="tel" id="restaurant_postal_code" name="s_other_contact" class="form-control" placeholder="" pattern="[\+]\d{2}[\(]\d{3}[\)]\d{4}[\-]\d{3}">
								</div>
							</div>
						</div>   
                        <!-- End row  -->
                        <div class="row">
							<div class="col-md-6">
								<div class="form-group">
                                	<label>Create a password</label>
                                   <input type="text" class="form-control" placeholder="Password"  id="password1" name="s_create_password">
								</div>
							</div>
                            <div class="col-md-6">
								<div class="form-group">
                                	<label>Confirm password</label>
                                   <input type="text" class="form-control" placeholder="Confirm password"  id="password2" name="s_confirm_password">
								</div>
							</div>
						</div><!-- End row  -->
                        <!--<div class="row">	
                            <div class="col-md-12">
								<div class="form-group">
                                	<label>Upload Picture</label>
                                   <input type="file" class="form-control" placeholder="" id="" name="profile_pic">

								</div>
							</div>
						</div><-- End row  -->
                        <div id="pass-info" class="clearfix"></div>
                        <div class="row">
                        	<div class="col-md-6">
									<label><input name="mobile" type="checkbox" value="" class="icheck" checked>Accept <a href="#0">terms and conditions</a>.</label>
							</div>
                            </div><!-- End row  -->
                        <hr style="border-color:#ddd;">
                        <div class="text-center"><button class="btn_full_outline" name="reg">Submit</button></div>
					</form>


        </div><!-- End col  -->
    </div><!-- End row  -->
</div><!-- End container  -->
<!-- End Content =============================================== -->

<!-- Footer ================================================== -->
	<?php 
       include_once('includes/footer.php'); 
    ?>
<!-- End Footer =============================================== -->

<div class="layer"></div><!-- Mobile menu overlay mask -->

<!-- Login modal --> 

<?php 
       include_once('includes/loginfooter.php');
        ?>   
<!-- End modal -->   
    
<!-- Register modal --> 
<?php 
       include_once('includes/regfooter.php');
        ?>     
<!-- End Register modal -->
    
     <!-- Search Menu -->
	<div class="search-overlay-menu">
		<span class="search-overlay-close"><i class="icon_close"></i></span>
		<form role="search" id="searchform" method="get">
			<input value="" name="q" type="search" placeholder="Search..." />
			<button type="submit"><i class="icon-search-6"></i>
			</button>
		</form>
	</div>
	<!-- End Search Menu -->
    
<!-- COMMON SCRIPTS -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/common_scripts_min.js"></script>
<script src="js/functions.js"></script>
<script src="assets/validate.js"></script>

</body>
</html>