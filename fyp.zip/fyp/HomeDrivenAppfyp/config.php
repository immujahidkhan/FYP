<?php

	$conn = mysqli_connect('localhost','root','','homedrivenapp');

	if(!$conn){
		mysqli_error($conn);
	}
	else{
	echo	"Database connection Successfully Connected!";
	}
?>