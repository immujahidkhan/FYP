<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin Panel </title>
    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="login">
      
      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <form action="logincheck.php" method="post">
              <h1>Login Form</h1>
                <input type="text" class="form-control" placeholder="E-Mail" name="email" required/>
                <input type="password" class="form-control" placeholder="Password" name="pass" required />
                <button class="btn btn-default submit">Log in</button>
              <div class="separator"></div>    
            </form>
          </section>
        </div>
      </div>
  </body>
</html>
