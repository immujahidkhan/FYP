<?php
include '../db.php';
    $id=$_POST['id'];
    $sql="Delete from service where service_id=$id";
	mysqli_query($con,$sql);
header("refresh:0;url=showservices.php");