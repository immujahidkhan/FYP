<?php
include("../db.php");
$id=$_POST['id'];
$name = $_POST['name'];
$sql = "UPDATE service SET
name='{$name}' where service_id =$id";
if(mysqli_query($con,$sql))
	{	
        header("refresh:0;url=showservices.php");
		exit;
	}

?>

