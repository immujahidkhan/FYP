<?php
include("../db.php");
$id=$_POST['id'];
$status = $_POST['status'];
$sql = "UPDATE provider SET status='{$status}' where id ='$id'";
if(mysqli_query($con,$sql))
	{	
        header("refresh:0;url=showproviders.php");
		exit;
	}

?>

