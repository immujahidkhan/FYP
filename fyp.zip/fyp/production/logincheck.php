<?php
	include '../db.php';
	$name = $_POST["email"];
	$password = $_POST["pass"];
	$sql="SELECT * FROM user where type='admin' and email='$name' and password= '$password';";
		$result =$con->query($sql);
        $row=mysqli_fetch_assoc($result);
		if(mysqli_num_rows($result)>0)
		{
            $_SESSION['id'] = $row['id'];
            $_SESSION['Aemail'] = $row['email'];
            $_SESSION['fname'] =$row['firstname'];
			header("refresh:0; url=index.php");
			exit;
		}
		else
		{
			header("refresh:0; url=production/login.php");
			exit;
		}
?>