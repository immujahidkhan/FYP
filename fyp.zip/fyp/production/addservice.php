<?php
include '../db.php';
    $name=$_POST['name'];
	$sql="INSERT INTO service(name)
    VALUES('$name')";
    mysqli_query($con,$sql);
    header("refresh:0; url=addservices.php");